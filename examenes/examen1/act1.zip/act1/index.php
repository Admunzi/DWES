<?php

/**
 * Examen 1 Practico
 * 
 * @author Daniel Ayala Cantador
 */
include 'config/tests_cnf.php';

$selectedTypeExam = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //Validamos selectDificultad
    if (isset($_POST['seleccionarExamen'])) {
        $selectedTypeExam = $_POST['seleccionarExamen'];
    }else{
        function convertirNumeroLetra($param){
            switch ($param) {
                case 1:
                    return "a";
                    break;
                case 2:
                    return "b";
                    break;
                case 3:
                    return "c";
                    break;
                            
                default:
                    break;
            }
        }
        var_dump($_POST);
        $errores = 0;
        foreach ($_POST as $key => $value) {
            if (convertirNumeroLetra($value) != $aTests[$selectedTypeExam]['Corrector'][$key]) {
                $errores++;
            }
        }
        if ($errores > 2) {
            echo("<h1>No has superado el examen</h1>");
        }
    }
    if ($selectedTypeExam != 0) {

        foreach ($aTests as $key => $aTest) {
            if ($aTest['idTest'] == $selectedTypeExam) { 
                echo("<h1>Examen Tipo $selectedTypeExam</h1>");
                echo("<form action=\"\" method=\"post\">");

                $i=0;
                $iFoto=1;
                foreach ($aTest['Preguntas'] as $key => $aPreguntas) {
                    echo($aPreguntas['Pregunta']);

                    echo("<select name=\"$i\">");
                        foreach ($aPreguntas['respuestas'] as $indiceRespuesta => $value) {
                            echo("<option value=\"$indiceRespuesta\">".$value."</option>");
                        }
                    echo("</select>");
                    echo("<img src=\"dir_img_test$selectedTypeExam/img$iFoto.jpg\" weight=\"50\" height=\"50\"><br><br>");
                    $iFoto++;
                    $i++;
                }
                echo("<input type=\"submit\" value=\"Enviar\">");
                echo("</form>");
            }
        }   
          
    }
}else {
    ?>
    <form action="" method="post">
        <label>Seleccionar examen: 
            <select name="seleccionarExamen">
                <?php
                    foreach ($aTests as $key => $value) {
                        echo("<option value=\"".$value['idTest']."\">".$value['idTest']." - ".$value['Permiso']." - ".$value['Categoria']."</option>");
                    }
                ?>
            </select>
        </label><br>
        <input type="submit" value="Enviar">
    </form>
    <?php
}